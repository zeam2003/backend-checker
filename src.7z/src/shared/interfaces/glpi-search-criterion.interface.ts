export interface GlpiSearchCriterion {
    field: string;
    searchtype: string;
    value: string | number;
  }
  