import { STATUS_LABELS } from '../constants/status-label';
import { decode } from './utils';

export function mapTicket(ticket: any) {
  return {
    id: ticket.id,
    name: ticket.name,
    status_code: ticket.status,
    status: STATUS_LABELS[ticket.status] || 'Desconocido',
    priority: ticket.priority ?? 'N/A',
    category: ticket.itilcategories_id ?? 'N/A',
    assignedTo:
      ticket._users_id_assign?.name ||
      `${ticket._users_id_assign?.firstname || ''} ${ticket._users_id_assign?.realname || ''}`.trim() ||
      'Sin asignar',
    entity: ticket.entities_id ?? 'N/A',
    date_creation: ticket.date_creation,
    date_mod: ticket.date_mod,
    content: decode(ticket.content || ''),
  };
}
