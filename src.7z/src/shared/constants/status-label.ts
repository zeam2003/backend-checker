/* export const STATUS_LABELS: { [key: number]: string } = {
  1: 'NUEVO',
  2: 'EN_CURSO',
  3: 'EN_PRUEBA',
  4: 'EN_ESPERA',
  5: 'RESUELTO',
  6: 'CERRADO',
};
 */

export const STATUS_LABELS = {
  1: 'Nuevo',
  2: 'En curso',
  3: 'En espera',
  4: 'Resuelto',
  5: 'Cerrado',
};

export const STATUS_GROUPS = {
  todos: [],
  en_curso: [2],
  en_espera: [3],
  cerrados: [4, 5],
};