

export class TicketItemDto {
    
    id: number;

    
    items_id: number;

    
    itemtype: string;

    
    tickets_id: number;

    
    date_creation?: string;

    
    date_mod?: string;
}