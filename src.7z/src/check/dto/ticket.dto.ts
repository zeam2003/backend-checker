

export class TicketDto {
  
  id: number;

  
  entities_id: string;

 
  name: string;

  
  date_mod: string;

  
  status: number;

  users_id_recipient: string;

  
  urgency: number;

  
  date?: string;

  
  time_to_resolve?: string;
}