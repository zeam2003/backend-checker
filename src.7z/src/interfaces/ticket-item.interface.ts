export interface TicketItem {
  id: number;
  name: string;
  date?: string;
  status?: string;
  priority?: string;
}
